package info.bliki.wiki.tags.util;

/**
 * this interface indicates that a tag has a body content
 */
public interface IBodyTag {

}
