package info.bliki.wiki.template.expr.eval;


public interface IBooleanBoolean1Function {
  public boolean evaluate(boolean arg1);
}
